<?php
$servername = "localhost";
$username = "root";  // Đổi nếu dùng user khác
$password = "";      // Đổi nếu có mật khẩu MySQL
$dbname = "Demologin";

// Kết nối MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}
?>
