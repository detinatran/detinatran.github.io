<?php
session_start();
include 'config.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$role = $_SESSION['role'];

// Lấy danh sách user
$sql = "SELECT username, email FROM user";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý User</title>
</head>
<body>
    <h2>Xin chào, <?php echo $username; ?>!</h2>
    <a href="logout.php">Đăng xuất</a>

    <h3>Danh sách người dùng</h3>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
            <?php if ($role == "admin") echo "<th>Hành động</th>"; ?>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['username']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo ($role == "admin") ? "******" : "******"; ?></td>
                <?php if ($role == "admin") { ?>
                    <td>
                        <a href="edit.php?username=<?php echo $row['username']; ?>">Sửa</a> |
                        <a href="delete.php?username=<?php echo $row['username']; ?>">Xóa</a>
                    </td>
                <?php } ?>
            </tr>
        <?php } ?>
    </table>

    <?php if ($role == "admin") { ?>
        <h3>Thêm người dùng mới</h3>
        <form method="POST" action="add.php">
            <label>Username:</label>
            <input type="text" name="new_username" required><br>

            <label>Password:</label>
            <input type="password" name="new_password" required><br>

            <label>Email:</label>
            <input type="email" name="new_email" required><br>

            <button type="submit">Thêm</button>
        </form>
    <?php } ?>
</body>
</html>
