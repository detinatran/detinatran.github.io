<?php
session_start();
include 'config.php';

if ($_SESSION['role'] != "admin") {
    die("Bạn không có quyền!");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $new_email = $_POST['new_email'];

    $sql = "UPDATE user SET email='$new_email' WHERE username='$username'";
    $conn->query($sql);
    header("Location: dashboard.php");
    exit();
}

if (isset($_GET['username'])) {
    $username = $_GET['username'];
    $sql = "SELECT * FROM user WHERE username='$username'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>

<form method="POST">
    <input type="hidden" name="username" value="<?php echo $row['username']; ?>">
    <label>Email mới:</label>
    <input type="email" name="new_email" value="<?php echo $row['email']; ?>" required>
    <button type="submit">Cập nhật</button>
</form>
