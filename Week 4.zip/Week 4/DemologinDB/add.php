<?php
session_start();
include 'config.php';

if ($_SESSION['role'] != "admin") {
    die("Bạn không có quyền truy cập!");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = $_POST['new_username'];
    $new_password = $_POST['new_password'];
    $new_email = $_POST['new_email'];

    $sql = "INSERT INTO user (username, password, email) VALUES ('$new_username', '$new_password', '$new_email')";
    if ($conn->query($sql) === TRUE) {
        echo "Thêm thành công!";
    } else {
        echo "Lỗi: " . $conn->error;
    }
}
header("Location: dashboard.php");
exit();
?>
