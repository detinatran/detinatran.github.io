<?php
session_start();
include 'config.php';

if ($_SESSION['role'] != "admin") {
    die("Bạn không có quyền!");
}

if (isset($_GET['username'])) {
    $username = $_GET['username'];
    $sql = "DELETE FROM user WHERE username='$username'";
    $conn->query($sql);
}

header("Location: dashboard.php");
exit();
?>
